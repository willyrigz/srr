-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:629
-- Generation Time: Feb 23, 2018 at 11:07 AM
-- Server version: 5.5.56-log
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `srr_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendances`
--

CREATE TABLE `attendances` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_sap` int(10) UNSIGNED NOT NULL,
  `attendance_date` date NOT NULL,
  `start` time DEFAULT NULL,
  `close` time DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attendances`
--

INSERT INTO `attendances` (`id`, `user_sap`, `attendance_date`, `start`, `close`, `created_at`, `updated_at`) VALUES
(1, 6274, '2018-02-17', '07:48:39', '16:04:17', NULL, '2018-02-23 09:22:23'),
(2, 1111, '2018-02-17', '07:48:47', NULL, NULL, '2018-02-23 09:22:23'),
(3, 1112, '2018-02-17', NULL, '19:03:23', NULL, '2018-02-23 09:22:23'),
(4, 1113, '2018-02-17', NULL, NULL, NULL, '2018-02-23 09:22:23');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `comment`, `report_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'hello', 5, 1, '2018-02-09 12:55:56', '2018-02-09 12:55:56'),
(2, 'bad job', 5, 1, '2018-02-09 13:38:47', '2018-02-09 13:38:47');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`) VALUES
(3, 'Health, Safety, Environment & Fire'),
(2, 'Human Resources'),
(1, 'Information Technology'),
(4, 'Quality Assurance');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(55, '2017_09_05_112351_create_comments_table', 1),
(56, '2017_10_15_114434_create_roles_table', 1),
(57, '2017_10_15_115509_create_role_users_table', 1),
(58, '2018_02_22_134026_create_attendances_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `report` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`id`, `title`, `report`, `user_id`, `created_at`, `updated_at`) VALUES
(1, '', 'This is a test report', 1, '2017-09-05 14:25:47', '2017-09-05 14:25:47'),
(2, '', 'This is Gabriel\'s First report', 2, '2017-09-06 08:40:46', '2017-09-06 08:40:46'),
(3, '', 'This is my second report', 4, '2017-09-07 09:08:52', '2017-09-07 09:08:52'),
(4, '', 'Alert Test', 1, '2017-09-11 09:18:58', '2017-09-11 09:18:58'),
(5, '', 'test', 1, '2017-09-11 09:28:26', '2017-09-11 09:28:26'),
(6, '', 'another test', 1, '2017-09-11 10:44:24', '2017-09-11 10:44:24'),
(7, '', 'include test', 1, '2017-09-11 10:45:51', '2017-09-11 10:45:51'),
(8, '', 'It now works', 1, '2017-09-11 10:51:01', '2017-09-11 10:51:01'),
(9, '', 'Last test', 1, '2017-09-11 10:52:15', '2017-09-11 10:52:15'),
(10, '', 'Speed test', 1, '2017-09-11 10:53:17', '2017-09-11 10:53:17'),
(11, '', 'click ok', 1, '2017-09-11 10:53:36', '2017-09-11 10:53:36'),
(12, 'A sample', 'THis is a sample', 1, '2018-02-09 12:02:41', '2018-02-09 12:02:41'),
(13, 'Another 1', 'THis is another', 1, '2018-02-09 12:03:47', '2018-02-09 12:03:47'),
(14, 'Alert Test', 'yeah', 1, '2018-02-09 12:04:42', '2018-02-09 12:04:42'),
(15, 'director', 'test', 7, '2018-02-09 17:07:12', '2018-02-09 17:07:12'),
(16, 'testes', '<p><b>Creating a professional looking dashboard for your website or app \r\nneedn&acirc;&#128;&#153;t be expensive. Thanks to this collection of the best free \r\nBootstrap admin templates you should be able to find a suitable user \r\ninterface (UI) toolkit for your project.</b><p><u>All of these tools include at least one pre-built dashboard homepage \r\ntemplate that can be customized and used as the foundation for your own \r\nproject. While creating your custom dashboard, you can choose from the \r\nselection of components, elements, and cards available in the template \r\npacks.</u></p><p>Adding charts, graphics, buttons, alerts, and tables are just some of\r\n the features you can add to your admin pages. Some templates include \r\nanimation effects and other UI elements to help make your dashboard more\r\n attractive. They&acirc;&#128;&#153;re also all mobile responsive so they should work on \r\nlarge and small screen displays. However, thanks to the online demos, \r\nyou can try them for yourself on your choice of devices to see if they \r\nmeet your requirements.</p><p><img style=\"width: 345px;\" data-filename=\"profile-bg.jpg\" src=\"15182746540.png\"><br></p><ul><li>Many of these free dashboard templates are also available as paid \r\nproducts with extra features and functionality on offer to those with \r\nmoney to spend. Thanks to this, if the needs of your project grow or \r\nyour budget increases in the future, you&acirc;&#128;&#153;ll have a clear upgrade path \r\navailable to you. However, if your project demands a more capable option\r\n from the outset, be sure to check out our <a href=\"https://athemes.com/collections/best-bootstrap-admin-templates/\" target=\"_blank\" rel=\"noopener\">collection of the best premium Bootstrap admin templates</a>.</li></ul><ol><li>For those getting started though, this collection of the best free \r\nadmin templates will help you launch your project without any financial \r\ninvestment required.</li></ol></p>\n', 2, '2018-02-10 13:57:34', '2018-02-10 13:57:34'),
(17, 'another', '<p>fsdfd<p>fsdfsd</p><p>sfd<img style=\"width: 345px;\" data-filename=\"profile-bg.jpg\" src=\"/reportUploads/2/15182780350.png\"><br></p></p>\n', 2, '2018-02-10 14:53:55', '2018-02-10 14:53:55'),
(18, 'df', '<p><img style=\"width: 890px;\" data-filename=\"img6.jpg\" src=\"/reportUploads/2/15182780670.png\"><br></p>\n', 2, '2018-02-10 14:54:27', '2018-02-10 14:54:27'),
(19, 'oko', '<p>Creating a professional looking dashboard for your website or app \r\nneedn&acirc;&#128;&#153;t be expensive. Thanks to this collection of the best free \r\nBootstrap admin templates you should be able to find a suitable user \r\ninterface (UI) toolkit for your project.<p>All of these tools include at least one pre-built dashboard homepage \r\ntemplate that can be customized and used as the foundation for your own \r\nproject. While creating your custom dashboard, you can choose from the \r\nselection of components, elements, and cards available in the template \r\npacks.</p><p><img data-filename=\"img1.jpg\" width=\"508\" height=\"339\" src=\"/reportUploads/2/15182934190.png\"></p><p>Adding charts, graphics, buttons, alerts, and tables are just some of \r\nthe features you can add to your admin pages. Some templates include \r\nanimation effects and other UI elements to help make your dashboard more\r\n attractive. They&acirc;&#128;&#153;re also all mobile responsive so they should work on \r\nlarge and small screen displays. However, thanks to the online demos, \r\nyou can try them for yourself on your choice of devices to see if they \r\nmeet your requirements.</p></p>\n', 2, '2018-02-10 19:10:19', '2018-02-10 19:10:19'),
(20, 'f', '<p>ffsf<br></p>\n', 2, '2018-02-10 19:14:16', '2018-02-10 19:14:16');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `slug`, `permissions`, `created_at`, `updated_at`) VALUES
(1, 'Staff', 'staff', '{\"create-report\":true}', '2017-10-15 12:42:54', '2017-10-15 12:42:54'),
(2, 'Director', 'director', '{\"view-staff\":true,\"update-report\":true,\"view-report\":true,\"view-hod\":true}', '2017-10-15 12:42:54', '2017-10-15 12:42:54'),
(3, 'HOD', 'hod', '{\"create-report\":true,\"view-staff\":true,\"update-report\":true,\"view-report\":true}', NULL, NULL),
(4, 'Attendance Synchronizer', 'attendance_synchronizer', '{\"upload-attendance\":true}', '2018-02-21 23:00:00', '2018-02-21 23:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `role_users`
--

CREATE TABLE `role_users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_users`
--

INSERT INTO `role_users` (`user_id`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 3, NULL, NULL),
(2, 1, NULL, NULL),
(4, 1, NULL, NULL),
(5, 3, NULL, NULL),
(6, 1, NULL, NULL),
(7, 2, NULL, NULL),
(8, 3, NULL, NULL),
(9, 4, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `sap` int(11) UNSIGNED NOT NULL,
  `role` tinyint(4) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_id` int(11) NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `sap`, `role`, `name`, `email`, `department_id`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 6274, 1, 'Misan O', 'misan@misan.com', 1, '$2y$10$CNy4YQK4rCMqeqtwKZFp3.PhqQmPDNWD/4/qrIGoU0aH77mvcPW4m', '3GpXiqJeqx5haRLkgkwhqTxpNKSuj8WXySA1mZlBJ09buqg3KaRaSxNprPYw', '2017-09-05 10:33:54', '2017-09-05 10:33:54'),
(2, 1111, 2, 'Gabriel', 'gab@misan.com', 1, '$2y$10$0ZNX5zk06JwLNv1AqPZm8eEcLHLhdMQNm6jJNdoSZsCLy7J4SY1RK', 'XwozDTB8cwqvb8Txpzz48Z4Z3ckoq93G0zrvlRprrF1glyYBz3nQXXD7b356', '2017-09-06 08:40:01', '2017-09-06 08:40:01'),
(4, 1112, 2, 'staff user', 'staff@dangote.com', 2, '$2y$10$TSqf66z0dCYTqM1f9pvhReAkUMWQrK4nscPD.R//qlQJKunQK58Qe', 'x0MlA6N8DvQFEfxLlJRCnFQ0TMP90GDo5kIUJbBfdUICvgNeHgI67GMZKN83', '2017-10-15 13:43:15', '2017-10-15 13:43:15'),
(5, 1113, 2, 'director', 'director@misan.com', 1, '$2y$10$4vCcMtEDyPE/ewhNHKssy.ThD8UmCOYP6OneaJ8jDTgl/6BHyBMUO', 'u0MeBVQfswFugkLoN0MYxKR5GykqX0YVDrMUptJ5TgZLsYsZYLd38XEfFCHu', '2018-02-09 14:24:26', '2018-02-09 14:24:26'),
(6, 1114, 2, 'hod', 'hod@misan.com', 1, '$2y$10$hjUXKjG0vrljQK5KNsueWukLgagDXCaM7I.E7oJq630jLBGp5v676', 'Pcrpd3dYDaYl5JGPS3VVqu0bFyDytXeXnq0781RCXyxr3H24ytlHP78eoHVC', '2018-02-09 14:25:14', '2018-02-09 14:25:14'),
(7, 1115, 2, 'hrdirector', 'hrd@dangote.com', 1, '$2y$10$ywyWJtjbagbor2aM1ESBbuncstA6wqXEMHTOGeFCecDj5E6lNE8FS', 'OCV3bIje9KG7hxpNQozrqbIpv8qXYGuO09Upnpj0xFGWZya9doJKpuZw5va4', '2018-02-09 16:30:25', '2018-02-09 16:30:25'),
(8, 1116, 3, 'hrhod', 'hrhod@dangote.com', 2, '$2y$10$B4uOOTXZJdfq4TE6ig39deSaUp5wvyVzQtO7N85lpvKUvJF6LXep.', 'QadYxlI8eYBXvMALBuBv8cCl4EzMpQCF7I06k0CPfl84DIPEUCpMfwxMzF1i', '2018-02-09 16:39:51', '2018-02-09 16:39:51'),
(9, 1110, 4, 'Anyone', 'a@dangote.com', 3, '$2y$10$0dl./vbsrH8VaWBjlAYzsuopU2p4JMpHgLCTiW7JWo4JhIjucMZLa', NULL, '2018-02-22 13:32:18', '2018-02-22 13:32:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendances`
--
ALTER TABLE `attendances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `attendances_user_sap_attendance_date_unique` (`user_sap`,`attendance_date`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_report_id_foreign` (`report_id`),
  ADD KEY `comments_user_id_foreign` (`user_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reports_user_id_foreign` (`user_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_slug_unique` (`slug`);

--
-- Indexes for table `role_users`
--
ALTER TABLE `role_users`
  ADD UNIQUE KEY `role_users_user_id_role_id_unique` (`user_id`,`role_id`),
  ADD KEY `role_users_role_id_foreign` (`role_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_sap_unique` (`sap`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendances`
--
ALTER TABLE `attendances`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendances`
--
ALTER TABLE `attendances`
  ADD CONSTRAINT `attendances_user_sap_foreign` FOREIGN KEY (`user_sap`) REFERENCES `users` (`sap`);

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_report_id_foreign` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`),
  ADD CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `role_users`
--
ALTER TABLE `role_users`
  ADD CONSTRAINT `role_users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
