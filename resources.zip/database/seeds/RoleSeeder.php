<?php
//use App\Role;
use Illuminate\Database\Seeder;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
     	$staff = Role::create([
     		'name'	      => 'Staff',
     		'slug'	      => 'staff',
     		'permissions' => json_encode([
     			'create-report' => true,
     		]),
     	]);

     	$director = Role::create([
     		'name'	      => 'Director',
     		'slug'	      => 'director',
     		'permissions' => json_encode([
     			'delete-report' => true,
     			'view-report' => true,
     		]),
     	]);   
    }
}
