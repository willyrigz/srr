<?php

namespace App\Http\Controllers;

use App\Attendance;
use Illuminate\Support\Facades\Input;
use DB;
use DateTime;
use Carbon\Carbon;
use Excel;
//use IsDate;
use Illuminate\Http\Request;

class AttendanceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $attendances = Attendance::all();

      
        return view('pages.attendance', compact('attendances'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function attendance_upload()

    {
        if(Input::hasFile('attendance_upload')){

            $path = Input::file('attendance_upload')->getRealPath();

            $data = Excel::load($path, function($reader) {

            })->get();
            function validateDate($date, $format = 'Y-m-d H:i:s')
            {
                $d = DateTime::createFromFormat($format, $date);
                return $d && $d->format($format) == $date;
            }

            if(!empty($data) && $data->count()){

                foreach ($data as $key => $value) {
                    if($value->id != null){
                        $getDate = $value->date;
                        

                        if(validateDate($getDate) == TRUE){
                            $trimTheDateString1 = date_format(($value->date), 'd/m/Y');
                            $stringtheDate = strval($trimTheDateString1);
                            $trimTheDateString = trim($stringtheDate);
                            
                            $attendance_datestring = DateTime::createFromFormat('d/m/Y', $trimTheDateString)->format('Y-m-d');
                            $attendance_totime   = strtotime($attendance_datestring);
                            $attendance_dateformat = date("Y-m-d",$attendance_totime);
                            $attendance_date = Carbon::parse($attendance_dateformat);
                        } else {
                            $trimTheDateString = trim($getDate);
                            $attendance_datestring = DateTime::createFromFormat('d/m/Y', $trimTheDateString)->format('Y-m-d');
                            $attendance_totime   = strtotime($attendance_datestring);
                            $attendance_dateformat = date("Y-m-d",$attendance_totime);
                            $attendance_date = Carbon::parse($attendance_dateformat);
                        }
                        // if(IsDate($value->date) == TRUE){
                        //     $stringtheDate = strval($value->date);
                        //     $trimTheDateString = trim($stringtheDate);
                        //     $trimTheDateString1 = date_format($trimTheDateString, 'd/m/Y');
                        //     return($trimTheDateString1);
                        // } else {
                        //     return(' fuck ');
                        // }
                        
                        
                        //$attendance_date = $attendance_date->format('l jS \\of F Y h:i:s A');
                        //return($attendance_date);
                        if($value->start != null){
                            $start_time_str = $value->start;
                            $start_time = Carbon::parse($start_time_str);
                            //$start_time = $start_time_str_date->toTimeString();
                        } else {
                            $start_time = null;
                        }
                        if($value->close != null){
                            $close_time_str = $value->close;
                            $close_time = Carbon::parse($close_time_str);
                            //$close_time = $close_time_str_date->toTimeString();
                        } else {
                            $close_time = null;
                        }
                        $attendance = Attendance::where('user_sap', $value->id)->where('attendance_date', $attendance_date)->get();
                        $attendance_count = $attendance->count();
                        if($attendance_count > 0){
                            $attendance = Attendance::where('user_sap', $value->id)->where('attendance_date', $attendance_date)->update(['start' => $start_time, 'close' => $close_time]);
                        } else {
                            $insert[] = ['user_sap' => $value->id, 'attendance_date' => $attendance_date, 'start' => $start_time, 'close' => $close_time];
                        }
                        
                    }
                }
               //return($insert);
                if(!empty($insert)){

                    DB::table('attendances')->insert($insert);

                    dd('Insert Record successfully.');

                }

            }

        }

        return back();

    }

    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Attendance  $attendance
     * @return \Illuminate\Http\Response
     */
    public function show(Attendance $attendance)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Attendance  $attendance
     * @return \Illuminate\Http\Response
     */
    public function edit(Attendance $attendance)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Attendance  $attendance
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Attendance $attendance)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Attendance  $attendance
     * @return \Illuminate\Http\Response
     */
    public function destroy(Attendance $attendance)
    {
        //
    }
}
