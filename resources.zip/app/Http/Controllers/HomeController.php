<?php

namespace App\Http\Controllers;
use Mail;
use Alert;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function sendmail()
    {
      return view('layouts.app2');

 //      $data = array(
      
 //         );

 //     // Mail::send('emails.testmail', $data, function($message) use ($data){
 //     //      $message->from('omatsone.o@gmail.com', 'mail test');
 //     //      $message->to('willyrigz@gmail.com', 'mail test');
 //     //      $message->subject('Bdoo');
 //     //    });
 //        //$user=User::all();
         
 // Mail::send('emails.test', $data, function($message) use ($data){
 //          $message->from('omatsone.o@gmail.com', 'mail test');
 //          $message->to('willyrigz@gmail.com', 'mail test');
 //          $message->subject('Bdoo');
 //        });
 //        // $drivers_license_exipiring = array();
 //        // $drivers_license_exipiring = Driver::where('live', 0)
 //        //         ->where( 'license_expiration_date', '<', Carbon::now()->addDays(60))
 //        //         ->where( 'license_expiration_date', '>', Carbon::now())
 //        //         ->orderBy('license_expiration_date', 'ASC')
 //        //         ->get();
 //        // $current_day = array();     
 //        // $current_day = Carbon::now();
 //        //  $data = array(
 //        //     'drivers_license_exipiring' => $drivers_license_exipiring,
 //        //     'current_day' => $current_day,
 //        // );
         
 //        //     Mail::send('emails.testmail', $data, function($m) use ($user)

 //        //         {

 //        //             foreach ($user as $user) {

 //        //                 $m->to($user->email)->subject('Expiring Drivers License');

 //        //             }                     

 //        //         });
 //        //  // $donatebooks->create($request->all());
 //        //   session()->flash('message','Email Sent Successful');
 //        //   return view('admin_template');
    }
    public function index()
    {
        return view('home');
    }

    public function myNotification($type)

    {

        switch ($type) {

            case 'message':

                alert()->message('Sweet Alert with message.');

                break;

            case 'basic':

                alert()->basic('Sweet Alert with basic.','Basic');

                break;

            case 'info':

                alert()->info('Sweet Alert with info.');

                break;

            case 'success':

                alert()->success('Sweet Alert with success.','Welcome to ItSolutionStuff.com')->autoclose(3500);

                break;

            case 'error':

                alert()->error('Sweet Alert with error.');

                break;

            case 'warning':

                alert()->warning('Sweet Alert with warning.');

                break;

            default:

                # code...

                break;

        }


        return view('pages.my-notification');

    }
}
