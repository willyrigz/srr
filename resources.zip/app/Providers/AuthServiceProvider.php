<?php

namespace App\Providers;

use App\Report;
use App\User;
use Illuminate\Support\Facades\Gate;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        'App\Model' => 'App\Policies\ModelPolicy',
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();
        $this->registerReportPolicies();
        //
    }

    public function registerReportPolicies()
    {
        Gate::define('upload-attendance', function($user){
            return $user->hasAccess(['upload-attendance']);
        });

        Gate::define('create-report', function($user){
            return $user->hasAccess(['create-report']);
        });

        Gate::define('view-staff', function($user){
            return $user->hasAccess(['view-staff']);
        });

        Gate::define('update-report', function($user, \App\Report $reports){
            return $user->hasAccess(['update-report']) or $user->id == $reports->user_id;
        });

        Gate::define('view-report', function($user, Report $reports){
            return $user->hasAccess(['view-report']) or $user->id == $reports->user_id;
        });

        Gate::define('see-all-reports', function($user, Report $reports){
            return $user->inRole('director') or $user->id == $reports->user_id or $user->department_id == $reports->user->department_id;
        });

        Gate::define('director', function($user){
            return $user->inRole('director');
        });

        Gate::define('hod', function($user, User $users){
            return $users->inRole('hod') or $users->inRole('director');
        });

        Gate::define('department', function($user, User $users){
            return $user->department_id == $users->department_id;
        });
    }
}
